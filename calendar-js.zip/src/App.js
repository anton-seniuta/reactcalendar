import "./App.css";
import Header from "./сomponents/Header";
import Body from "./сomponents/Body";

function App() {
  return <div className="app-body">
    <Header></Header>
    <Body></Body>
  </div>;
}

export default App;
