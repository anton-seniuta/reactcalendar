import "./Day.css";

function Day({day}) {
  
  console.log(day);
  debugger
  return <div className="day">{day}</div>;
}

export default Day;
