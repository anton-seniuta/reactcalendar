import "./Calendar.css";
import Day from "./Day";


function Calendar(props) {
  let month = props.firstDay.getMonth(); 
  let calendarDays = []; //make  objects  add ids

  for (;;) {
    for (let i = 0; i < 7; i++) {
      calendarDays.push(props.firstDay.getDate() + "");
      props.firstDay.setDate(props.firstDay.getDate() + 1);
    }
    if (props.firstDay.getMonth() !== month + 1) break;
  }

  console.log(calendarDays);

  const value = [...calendarDays];
  
  // value[0] = 'Понедельник, ' + value[0];
  // value[1] = 'Вторник, ' + value[1];
  // value[2] = 'Среда, ' + value[2];
  // value[3] = 'Четверг,  ' + value[3]; 
  // value[4] = 'Пятница, ' + value[4];
  // value[5] = 'Суббота, ' + value[5];
  // value[6] = 'Воскресенье, ' + value[6];

  value[0] = 'Понедельник, ' + 11;
  value[1] = 'Вторник, ' + value[1];
  value[2] = 'Среда, ' + value[2];
  value[3] = 'Четверг,  ' + value[3]; 
  value[4] = 'Пятница, ' + value[4];
  value[5] = 'Суббота, ' + value[5];
  value[6] = 'Воскресенье, ' + value[6];

  const arr = [...value];
  console.log("map", arr.map((text) => text));
  console.log(arr);

  return (
    <div className="calendar">
      {arr.map((text) => (
      <Day key={Math.random()} day={text}/>
      ))
      }
    </div>
  );
}
  
export default Calendar;
 

